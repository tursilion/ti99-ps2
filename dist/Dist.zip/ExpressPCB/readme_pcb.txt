For the file 'ExpressPCB.zip':

These are schematic and board layouts for the software produced 
by the guys at http://ExpressPCB.com

Version 2 is tested. Version 3 is not yet developed.

ti keyboard rev 2.pcb is the PCB layout file
PS2Keyboard rev 2.sch is the schematic

This layout has room for a connector for the PS/2 port, two
power connectors (to permit pass-through TI-99 power), two
keyboard connectors (to permit connecting the original
keyboard at the same time, though I'm not sure whether that
will actually work!), and has pads to connect wires for the
Alt+F9 through Alt+F12 output functionality.

If you do order a set of boards, let me know, I might buy one
off you so I can test the layout. ;)

//
// (C) 2019 Mike Brent aka Tursi aka HarmlessLion.com
// This software is provided AS-IS. No warranty
// express or implied is provided.
//
// This notice defines the entire license for this software.
// All rights not explicity granted here are reserved by the
// author.
//
// You may redistribute this software provided the original
// archive is UNCHANGED and a link back to my web page,
// http://harmlesslion.com, is provided as the author's site.
// It is acceptable to link directly to a subpage at harmlesslion.com
// provided that page offers a URL for that purpose
//
// Source code, if available, is provided for educational purposes
// only. You are welcome to read it, learn from it, mock
// it, and hack it up - for your own use only.
//
// Please contact me before distributing derived works or
// ports so that we may work out terms. I don't mind people
// using my code but it's been outright stolen before. In all
// cases the code must maintain credit to the original author(s).
//
// -COMMERCIAL USE- Contact me first. I didn't make
// any money off it - why should you? ;) If you just learned
// something from this, then go ahead. If you just pinched
// a routine or two, let me know, I'll probably just ask
// for credit. If you want to derive a commercial tool
// or use large portions, we need to talk. ;)
//
// Commercial use means ANY distribution for payment, whether or
// not for profit.
//
// http://harmlesslion.com - visit the web page for contact info
//
